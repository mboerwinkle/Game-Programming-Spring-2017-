﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;

public class yeemageSprite : Sprite
{
    public int TargetX;
    public int TargetY;
    int myColor = 0;
    public int mycolor
    {
        get { return myColor; }

        set { myColor = value;
            if (myColor == 0) myPen = Pens.Black;
            if (myColor == 1) myPen = Pens.Yellow;
            if (myColor == 2) myPen = Pens.Blue;
            if (myColor == 3) myPen = Pens.Green;
            if (myColor == 4) myPen = Pens.IndianRed;
        }
    }
    Pen myPen = Pens.Black;
    public double Velocity = 10;
    public Graphics Image;
    public yeemageSprite(int color, int width, int height)
    {
        mycolor = color;

        X = width;
        Y = height;
        TargetX = width;
        TargetY = height;
    }

    //methods
    public override void paint(Graphics g)
    {
        g.DrawRectangle(myPen, new Rectangle(0, 0, 50, 50));
    }

    public new void act()
    {
        if (X < TargetX)
        {
            X += Velocity;
            if (mycolor == 4)
            parent.X -= Velocity * parent.Scale;
        }
        if (X > TargetX)
        {
            X -= Velocity;
            if (mycolor == 4)
                parent.X += Velocity * parent.Scale;
        }
        if (Y < TargetY)
        {
            Y += Velocity;
            if (mycolor == 4)
                parent.Y -= Velocity * parent.Scale;
        }
        if (Y > TargetY)
        {
            Y -= Velocity;
            if (mycolor == 4)
                parent.Y += Velocity*parent.Scale;
        }
    }
}