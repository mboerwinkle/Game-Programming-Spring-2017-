﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Threading;


namespace FormExample
{
    public partial class Form1 : Form
    {
        public static Form form;
        public static Thread updateThread;
        public static Thread renderThread;
        public static DateTime myTime;
        public static int fps = 30;
        public static int amount = 10;
        public static double running_fps = 30.0;
        public static double targX = 0, targY = 0;
        public static Sprite canvas = new Sprite();

        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true;
            form = this;
            renderThread = new Thread(new ThreadStart(render));
            updateThread = new Thread(new ThreadStart(update));
            Console.WriteLine("starting threads");
            updateThread.Start();
            renderThread.Start();

        }
        public static void update()
        {
            DateTime last = DateTime.Now;
            DateTime now = last;
            TimeSpan frameTime = new TimeSpan(10000000 / 200);
            while (true)
            {
                DateTime temp = DateTime.Now;
                now = temp;
                TimeSpan diff = now - last;
                if (diff.TotalMilliseconds < frameTime.TotalMilliseconds)
                    Thread.Sleep((frameTime - diff).Milliseconds);
                last = DateTime.Now;

                myTime = last;
           //     Console.WriteLine("updating");
                canvas.act();

            }
        }
        public static void render()
        {
            DateTime last = DateTime.Now;
            DateTime now = last;
            TimeSpan frameTime = new TimeSpan(10000000 / fps);
            while (true)
            {
                DateTime temp = DateTime.Now;
                now = temp;
                TimeSpan diff = now - last;
                if (diff.TotalMilliseconds < frameTime.TotalMilliseconds)
                    Thread.Sleep((frameTime - diff).Milliseconds);
                last = DateTime.Now;

                myTime = last;
                form.Invoke(new MethodInvoker(form.Refresh));

            }
        }

        private void UpdateSize()
        {
            
        }
   /*     protected virtual void OnKeyDown(KeyEventArgs e)
        {
            //base.OnKeyDown(e);
            //Console.WriteLine("asdffasdf");
 //           if (e.KeyCode == Keys.Left) elephant.TargetX -= 30;
        }*/
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            renderThread.Abort();
            updateThread.Abort();
        }

        protected override void OnResize(EventArgs e)
        {

            
            Refresh();
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            canvas.render(e.Graphics);
        }


    }
    
}
