﻿using FormExample;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class physicsSprite : Sprite
{
    static Random rand = new Random();
    public static int entCount = 0;
    static physicsSprite[] entList = new physicsSprite[1000];
    int size;
    int myColor = 0;
    public static int enemyCount = 0;
    public int mycolor
    {
        get { return myColor; }
        set
        {
            myColor = value;
            if (myColor == 0) myPen = Pens.Black;
            if (myColor == 1) myPen = Pens.Yellow;
            if (myColor == 2) myPen = Pens.Blue;
            if (myColor == 3) myPen = Pens.Green;
            if (myColor == 4) myPen = Pens.IndianRed;
        }
    }
    Pen myPen = Pens.Black;
    public double vx = 0;
    public double vy = 0;
    public double gx = 0;
    public double gy = 0.1;
    public bool tup = false;
    public bool tdown = false;
    public bool tleft = false;
    public bool tright = false;
    public bool canJump = false;
    public bool movable;
    public physicsSprite(int color, double width, double height, int size, bool movable)
    {
        this.movable = movable;
        this.size = size;
        mycolor = color;
        entList[entCount] = this;
        entCount++;
        X = width;
        Y = height;
    }

    //methods
    public override void paint(Graphics g)
    {
        g.DrawRectangle(myPen, new Rectangle(-size/2, -size/2, size, size));
    }
    int bulletNum = 0;
    public void shoot(double theta)
    {
       Program.bullet[bulletNum].X = X + Math.Cos(theta) * 50;
        Program.bullet[bulletNum].Y = Y + Math.Sin(theta) * 50;
        Program.bullet[bulletNum].vx = Math.Cos(theta) * 8;// +vx;
        Program.bullet[bulletNum].vy = Math.Sin(theta) * 8;// +vy;
        Program.bullet[bulletNum].gy = 0;
        bulletNum = (bulletNum+1)% 10;
    }
    public bool checkCollisions(double x, double y)
    {
        bool collides = false;
        for(int idx = 0; idx < entCount; idx++)
        {
            if(entList[idx] == this)
            {
                continue;
            }
            physicsSprite o = entList[idx];
            if(Math.Abs(o.X - x) < o.size/2+size/2 && Math.Abs(o.Y - y) < o.size / 2 + size / 2)
            {
                collides = true;
                if(mycolor == 3 && o.mycolor == 0)
                {
                    o.X = 10000000;
                    Console.WriteLine(enemyCount);
                    enemyCount--;
                    if (enemyCount == 0) parent.winStatus = 1;
                }
                if ((mycolor == 4 && o.mycolor == 0) || (mycolor == 0 && o.mycolor == 4))
                {
                    parent.winStatus = -1;
                }

                    if (Math.Abs(o.X -x) < Math.Abs(o.Y - y))//y collision
                {
                    if (o.Y < y)
                    {
                        tup = true;
                        o.tdown = true;
                    }
                    else
                    {
                        tdown = true;
                        o.tup = true;
                    }
                }else//x collision
                {
                    if(o.X < x)
                        {
                            tleft = true;
                            o.tright = true;

                        }else
                        {
                            tright = true;
                            o.tleft = true;
                        }
                }
            }
        }
        return collides;
    }
    public new void act()
    {
        if (movable)
        {

            double x = X + vx;
            double y = Y + vy;
            if(checkCollisions(x, y))
            {
                if (tup || tdown) vx *= 0.8;
             //   if (tright || tleft) vy /= 0.8;
                if (tup && vy < 0) vy = 0;
                if (tdown && vy > 0) vy = 0;
                if (tright && vx > 0) vx = 0;
                if (tleft && vx < 0) vx = 0;
                if(gx < 0  && !tleft) vx += gx;
                if (gx > 0 && !tright) vx += gx;
                if (gy < 0 && !tup) vy += gy;
                if (gy > 0 && !tdown) vy += gy;
                if (tdown) canJump = true;
            }
            else
            {
                X = x;
                Y = y;

                if (myColor == 4)
                {
                    parent.X -= vx * parent.Scale;
                    parent.Y -= vy * parent.Scale;
                }
                vx += gx;
                vy += gy;
            }
            tup = false; tdown = false; tleft = false; tright = false;

        }

        if(myColor == 0)
        {
            if (Program.elephant.X > X) vx = 1;
            if (Program.elephant.X < X) vx = -1;
            if (rand.Next(0, 100) == 0 && canJump)
            {
                canJump = false;
                vy -= 5;
            }
        }
    }
}
