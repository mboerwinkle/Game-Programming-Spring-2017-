﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Windows.Forms;

namespace FormExample
{
public class Program : Form1
{
        public static physicsSprite elephant;
        public static physicsSprite[] bullet;
public static void reset()
        {
            Console.WriteLine("resetting");
            physicsSprite.enemyCount = 0;
            physicsSprite.entCount = 0;
            Program.canvas = new Sprite();
            String map = 
                "wwwwwwwwwwwwwwwwwwww\nwc       eeeeeeeee w\nw                  w\nw                  w\nw ww               w\nwwwwwwwwwwwwwwwwwwwww";//Properties.Resources.level1;
            String[] lines = map.Split('\n');
            int width = 20;
            int height = 6;
            bullet = new physicsSprite[10];
            for(int temp = 0; temp < 10; temp++)
            {
                bullet[temp] = new physicsSprite(3, 0, 0, 8, true);
                Program.canvas.add(bullet[temp]);
                bullet[temp].gy = 0;
            }


            for (int j = 0; j < height; j++)
            {
                for (int i = 0; i < width; i++)
                {
                    if (lines[j][i] == 'w')
                    {
                        Program.canvas.add(new physicsSprite(2, i * 100, j * 100, 100, false));
                    }
                    if (lines[j][i] == 'c')
                    {
                        elephant = new physicsSprite(4, i * 100, j * 100, 50, true);

                    }
                    if (lines[j][i] == 'e')
                    {
                        Program.canvas.add(new physicsSprite(0, i * 100, j * 100, 15, true));
                        Program.canvas.add(new physicsSprite(0, i * 100+50, j * 100, 15, true));
                        Program.canvas.add(new physicsSprite(0, i * 100+50, j * 100+50, 15, true));
                        Program.canvas.add(new physicsSprite(0, i * 100, j * 100+50, 15, true));
                        physicsSprite.enemyCount+=4;
                    }

                }

            }
            Program.canvas.add(elephant);

        }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            float dx = e.X - ClientSize.Width / 2;
            float dy = e.Y - ClientSize.Height / 2;
            double theta = Math.Atan2(dy, dx);
            elephant.shoot(theta);
        }
protected override void OnKeyDown(KeyEventArgs e)
{
    if (e.KeyCode == Keys.Right)
    {
                if(elephant.vx < 5)
                elephant.vx = 5;
    }
    if (e.KeyCode == Keys.Left)
    {
                if (elephant.vx > -5)
                    elephant.vx = -5;
            }
    if (e.KeyCode == Keys.Up)
    {
                if (elephant.vy > -5 && elephant.canJump)
                {
                    elephant.vy = -5;
                    elephant.canJump = false;
                }

            }
    if (e.KeyCode == Keys.Down)
    {

            }
    if (e.KeyCode == Keys.R)
    {
        reset();
        OnResize(new EventArgs());
    }
}

protected override void OnLoad(EventArgs e)
{
base.OnLoad(e);
fixScale();
}

protected override void OnResize(EventArgs e)
{
            Console.WriteLine("resizing");
            base.OnResize(e);
fixScale();
}

public void fixScale()
{
canvas.Scale=Math.Min(ClientSize.Width, ClientSize.Height)/1000.0f;
            canvas.X = -elephant.X * canvas.Scale + (float)ClientSize.Width/2;// / 1000.0f;
            canvas.Y = -elephant.Y * canvas.Scale + (float)ClientSize.Height/2;// / 1000.0f;
        }


/// <summary>
/// The main entry point for the application.
/// </summary>
[STAThread]
static void Main()
{
            Program.reset();

Application.Run(new Program());
}
}
}